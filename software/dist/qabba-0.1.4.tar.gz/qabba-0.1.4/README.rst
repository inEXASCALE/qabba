
QABBA: To do 