__version__='0.1.2'
from .qabba import QABBA, fastQABBA, fastQABBA_len, fastQABBA_inc
